import glob
import os
import PIL
import time

def win_crop_images(input_files):
    step_1 = windowing(np.array(PIL.Image.open(input_files)), 90, 110)
    step_2 = crop_center(step_1)
        
    return step_2

while(True):
    time.sleep(0.01)
    for image_file in  glob.glob("/home/jovyan/data/export/train/*/*/*.png"):
         # ... your preprocessing steps
         # ... your procedure to store the file in /output
         preprocessed_image = win_crop_images(image_file)
         basename = os.path.basename(image_file)
         os.path.join("/home/jovyan/data/output/basename"+".png")
         os.remove(image_file)